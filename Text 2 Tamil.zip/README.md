# Text 2 Tamil
    The Text 2 Tamil is a Browser Extension which enables end users to Select a Piece of text & translate those text to Tamil Language and speaks the same.

# Programming Language Used
    Javascript
    Python

# Technologies Used
    Browser Extension has the capablity to send the data to the executable Present in the native machine, With the help of that provided the text to the native executable which is build up with Python inclusive of Google Translator & Pyttx3 Package which helps to translate the text & speak the same respectively.

# Business Usecases
    In Real time, If you need to translate & Speak the same, You need to Go for google translate Website & then translate the same & then make it to speak. In order to minimise it, Just right click the text & Say to read it in tamil, our Extension will do that for you.
    