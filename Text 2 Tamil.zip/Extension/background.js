
let port;

// Connect to the Native Messaging Host once when the extension starts
chrome.runtime.onInstalled.addListener(() => {
  port = chrome.runtime.connectNative("com.ras.languagetranslator");
  console.log("Connected to Native Messaging Host.");
});


// Add a context menu for selected text
chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
      id: "printSelectedText",
      title: "Read it in tamil",
      contexts: ["selection"] // Show this menu only when text is selected
    });
  });
  
  // Listen for context menu clicks
  chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === "printSelectedText" && info.selectionText) {
      console.log("Selected text:", info.selectionText);

      port.postMessage({ text: info.selectionText });
      console.log("Sent selected text to native host:", info.selectionText);
    }
  });
  