from deep_translator import GoogleTranslator
from gtts import gTTS
import pygame
import sys
import os
import struct

count=0

def speak_in_tamil(text_to_speak):
    # Translate from English to Tamil
    translated_text = GoogleTranslator(source='en', target='ta').translate(text_to_speak)
    #print("Translated Text (Tamil):", translated_text)

    tts = gTTS(text=translated_text, lang='ta',slow=False)
    global count
    filename = "tamil_"+str(count)
    count += 1
    tts.save(filename)

    pygame.mixer.init()
    pygame.mixer.music.load(filename)
    pygame.mixer.music.play()
    #os.remove("tamil_audio.mp3")

def read_message():
    # Read exactly 4 bytes from standard input
    raw_length = sys.stdin.read(4)
    if len(raw_length) < 4:
        return None
    # Unpack the 4 bytes into an integer (message length)
    message_length = struct.unpack('I', raw_length.encode('latin1'))[0]
    # Read the JSON message based on its length
    message = sys.stdin.read(message_length)
    return message


while True:
    message = read_message()
    if message is None:
        break
    speak_in_tamil(message)



